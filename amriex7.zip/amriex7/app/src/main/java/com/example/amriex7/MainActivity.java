package com.example.amriex7;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Color;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
{

    Button bt1,bt2;
    TextView text;
    ImageView im;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = (Button)findViewById(R.id.button);
        bt2= (Button) findViewById(R.id.button2);
        text = (TextView) findViewById(R.id.text);
        im = (ImageView)findViewById(R.id.imageView);

        bt1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                new Thread(new Runnable()
                {
                    @Override
                    public void run() {

                        im.post(new Runnable() {
                            @Override
                            public void run() {
                                Paint paint = new Paint();
                                paint.setColor(Color.BLUE);
                                Bitmap tempBitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
                                Canvas tempCanvas = new Canvas(tempBitmap);
                                tempCanvas.drawRect(20, 20, 50, 80, paint);
                                im.setImageBitmap(tempBitmap);

                                text.setText("Start coordinates:    X-Coordinate=20   Y-Coordinate=20");
                            }
                        });
                    }


                }).start();
            }
        });

        bt2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                new Thread(new Runnable()
                {
                    @Override
                    public void run() {
                        im.post(new Runnable() {
                            @Override
                            public void run() {
                                Paint paint = new Paint();
                                paint.setColor(Color.GREEN);
                                Bitmap tempBitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
                                Canvas tempCanvas = new Canvas(tempBitmap);
                                tempCanvas.drawRect(75, 50, 130, 100, paint);
                                im.setImageBitmap(tempBitmap);

                                text.setText("After movement:    X-Coordinate=75   Y-Coordinate=50");
                            }
                        });
                    }


                }).start();
            }
        });
    }
}