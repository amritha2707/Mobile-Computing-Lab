package com.example.amri;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements OnDateSetListener{

    TextView txt;
    TextView txt2;
    TextView txt3;
    TextView txt4;
    TextView showdate;
    Button btn;
    Button btnpick;
    Button showdata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=(TextView) findViewById(R.id.editText);
        txt2=(TextView) findViewById(R.id.editText3);
        txt3=(TextView) findViewById(R.id.editText4);
        txt4=(TextView) findViewById(R.id.editText6);
       btn=(Button) findViewById(R.id.reset);

        showdate=findViewById(R.id.showdate);
        btnpick=(Button) findViewById(R.id.pickdate);

        showdata = (Button)findViewById(R.id.data);



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt.setText(" ");
                txt2.setText(" ");
                txt3.setText(" ");
                txt4.setText(" ");
                showdate.setText(" ");
            }
        });

        btnpick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        showdate.setOnClickListener(new View.OnClickListener() {
            String t;

            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,SecondActivity.class);
                t=txt.getText().toString();

                i.putExtra("Name",t);
                startActivity(i);
                finish();
            }
        });
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog
                (this,
                        this,
                       Calendar.getInstance().get(Calendar.YEAR),
                        Calendar.getInstance().get(Calendar.MONTH),
                        Calendar.getInstance().get(Calendar.DAY_OF_MONTH)

                        );
        datePickerDialog.show();
    }


    public void onDateSet(DatePicker view, int year, int month, int day) {
        int mon= month+1;
        String date = day + "/" + mon + "/" + year;
        showdate.setText(date);
    }
}





