package com.example.amri;


import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

        TextView tv;
        String st;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tv= findViewById(R.id.name);

        st=getIntent().getExtras().getString("Name");
        tv.setText(st);
    }
}
