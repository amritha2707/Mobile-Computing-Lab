package com.example.ex5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_LONG;

public class activity2 extends AppCompatActivity {

    Database mydb;
    EditText name,address,number,email;
    Button btnAddData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);

        mydb = new Database(this);
        name = (EditText)findViewById(R.id.name);
        address = (EditText)findViewById(R.id.address);
        number = (EditText)findViewById(R.id.number);
        email = (EditText)findViewById(R.id.email);
        btnAddData = (Button)findViewById(R.id.submit);

        AddData();
    }

    public  void AddData() {
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = mydb.insertData(name.getText().toString(),
                                address.getText().toString(),
                                number.getText().toString(),
                                email.getText().toString());
                        if(isInserted == true)
                            Toast.makeText(activity2.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(activity2.this,"Data not Inserted", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
}
