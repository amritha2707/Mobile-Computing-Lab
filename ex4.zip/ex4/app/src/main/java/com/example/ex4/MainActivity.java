package com.example.ex4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.graphics.Matrix;
import android.widget.ImageView;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

import static com.example.ex4.R.drawable.bird;

public class MainActivity extends AppCompatActivity {
    ImageView bird;


    AnimationDrawable rocketAnimation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setContentView(new MyView(this));

        ImageView rocketImage = (ImageView) findViewById(R.id.bird);
        rocketImage.setBackgroundResource(R.drawable.bird);
        rocketAnimation = (AnimationDrawable) rocketImage.getBackground();

        rocketImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rocketAnimation.start();
            }
        });



    }

    public class MyView extends View {

        public MyView(Context context) {
            super(context);
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override


        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            Paint paint = new Paint();
            int x = getWidth();
            int y = getHeight();
            int radius = 100;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.BLACK);

            canvas.drawPaint(paint);
            paint.setColor(Color.YELLOW);
            paint.setStrokeWidth(7);

            canvas.drawCircle(x / 4, y / 4, radius, paint);
            paint.setColor(Color.GREEN);
            canvas.drawLine(x / 10, y / 25, x / 2, y / 25, paint);
            paint.setColor(Color.BLUE);
            canvas.drawRect(100, 550, 500, 800, paint);
            paint.setColor(Color.RED);
            canvas.drawArc(180, 100, 280, 260, 0, 90, true, paint);
            paint.setColor(Color.WHITE);

        }




    }
}